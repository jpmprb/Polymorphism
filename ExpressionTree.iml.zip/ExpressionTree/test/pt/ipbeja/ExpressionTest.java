package pt.ipbeja;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ExpressionTest {
    @Test
    void name() {
        Expression sum = new Addition(new Value(2.0), new Value(3.0));
        System.out.println(sum.evaluate());

        Expression value =  new Value(3.0);
        System.out.println(value.evaluate());



        /* 2 + 4 * 5
                 +
                / \
               2   *
                  / \
                 4   5
        */
        Expression tree = new Addition(new Value(2.0),
                new Multiplication(new Value(4.0),
                                   new Value(5.0)
                )
        );

        double result = tree.evaluate();
        assertEquals(22.0, result, 0.00001);
        System.out.println(result);
    }
}