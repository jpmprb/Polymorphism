package pt.ipbeja.estig.fifteen.model;

/**
 * Directions for movement in model
 * @author João Paulo Barros
 * @version 2021/05/18
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
