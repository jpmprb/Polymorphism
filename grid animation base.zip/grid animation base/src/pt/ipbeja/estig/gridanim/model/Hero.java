package pt.ipbeja.estig.gridanim.model;

/**
 * The Hero class
 *
 * @author João Paulo Barros
 * @version 2021/05/31
 */
public class Hero extends Mobile {

    // TO DO
}
