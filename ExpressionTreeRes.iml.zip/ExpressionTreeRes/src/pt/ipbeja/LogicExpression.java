package pt.ipbeja;

public interface LogicExpression {
    boolean evaluateBoolean();
}
