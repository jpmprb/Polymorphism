package pt.ipbeja;

/**
 * A binary operation is a kind of arithmetic expression
 *
 * @author Joao Paulo Barros
 * @version 2021/04/05
 */
public class IFOperator implements Expression
{
    private LogicExpression condition;
    private Expression thenValue;
    private Expression elseValue;

    public IFOperator(LogicExpression condition, Expression thenValue, Expression elseValue) {
        this.condition = condition;
        this.thenValue = thenValue;
        this.elseValue = elseValue;
    }

    public LogicExpression getCondition() {
        return this.condition;
    }

    public Expression getThenValue() {
        return this.thenValue;
    }

    public Expression getElseValue() {
        return this.elseValue;
    }

    @Override
    public double evaluate() {
        return this.condition.evaluateBoolean() ?
                this.thenValue.evaluate() :
                this.elseValue.evaluate();
    }
}
