package pt.ipbeja;

/**
 * Division is a binary operation
 *
 * @author Joao Paulo Barros
 * @version 2005/04/30
 */
public class BiggerThan extends BinaryOperation implements LogicExpression
{
    public BiggerThan(Expression left, Expression right)
    {
        super(left, right);
    }

    public double evaluate()
    {
        return this.evaluateBoolean() ? 1.0 : 0.0;
    }
    public boolean evaluateBoolean()
    {
        return this.getLeft().evaluate() > this.getRight().evaluate();
    }
}

