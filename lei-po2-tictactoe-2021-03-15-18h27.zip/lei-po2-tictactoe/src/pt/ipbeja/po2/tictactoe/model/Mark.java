package pt.ipbeja.po2.tictactoe.model;

/**
 * @author Diogo Pina Manique
 * @version 13/03/2021
 */

public enum Mark {
    EMPTY, X_MARK, O_MARK
}
